﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using Microsoft.Win32;

namespace EmployeeManagementWPF
{
    public partial class MainWindow : Window
    {
        private EmployeeManager employeeManager;

        public MainWindow()
        {
            InitializeComponent();
            employeeManager = new EmployeeManager();
        }

        private void btnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            var employee = new Employee
            {
                Name = txtName.Text,
                Surname = txtSurname.Text,
                Age = int.Parse(txtAge.Text),
                Position = txtPosition.Text,
                Salary = decimal.Parse(txtSalary.Text)
            };
            employeeManager.AddEmployee(employee);
            RefreshEmployeeList();
        }

        private void btnEditEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (lstEmployees.SelectedIndex >= 0)
            {
                var employee = new Employee
                {
                    Name = txtName.Text,
                    Surname = txtSurname.Text,
                    Age = int.Parse(txtAge.Text),
                    Position = txtPosition.Text,
                    Salary = decimal.Parse(txtSalary.Text)
                };
                employeeManager.EditEmployee(lstEmployees.SelectedIndex, employee);
                RefreshEmployeeList();
            }
        }

        private void btnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (lstEmployees.SelectedIndex >= 0)
            {
                employeeManager.DeleteEmployee(lstEmployees.SelectedIndex);
                RefreshEmployeeList();
            }
        }

        private void btnLoadFromFile_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    employeeManager.LoadEmployeesFromFile(openFileDialog.FileName);
                    RefreshEmployeeList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnSaveToFile_Click(object sender, RoutedEventArgs e)
        {
            var saveFileDialog = new SaveFileDialog();
            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    employeeManager.WriteEmployeesToFile(saveFileDialog.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void RefreshEmployeeList()
        {
            lstEmployees.Items.Clear();
            foreach (var employee in employeeManager.Employees)
            {
                lstEmployees.Items.Add($"{employee.Name} {employee.Surname}, {employee.Age}, {employee.Position}, {employee.Salary}");
            }
        }

        private void lstEmployees_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (lstEmployees.SelectedIndex >= 0)
            {
                var employee = employeeManager.Employees[lstEmployees.SelectedIndex];
                txtName.Text = employee.Name;
                txtSurname.Text = employee.Surname;
                txtAge.Text = employee.Age.ToString();
                txtPosition.Text = employee.Position;
                txtSalary.Text = employee.Salary.ToString();
            }
        }
    }

    public abstract class Person
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
    }

    public class Employee : Person
    {
        public string Position { get; set; }
        public decimal Salary { get; set; }
    }

    public class EmployeeManager
    {
        public List<Employee> Employees { get; private set; }

        public EmployeeManager()
        {
            Employees = new List<Employee>();
        }

        public void AddEmployee(Employee employee)
        {
            Employees.Add(employee);
        }

        public void AddEmployee(List<Employee> employees)
        {
            Employees.AddRange(employees);
        }

        public void EditEmployee(int index, Employee updatedEmployee)
        {
            if (index >= 0 && index < Employees.Count)
            {
                Employees[index] = updatedEmployee;
            }
        }

        public void DeleteEmployee(int index)
        {
            if (index >= 0 && index < Employees.Count)
            {
                Employees.RemoveAt(index);
            }
        }

        public void LoadEmployeesFromFile(string path)
        {
            if (!File.Exists(path))
            {
                throw new FileNotFoundException("The specified file path does not exist.");
            }

            var lines = File.ReadAllLines(path);
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                if (parts.Length == 5)
                {
                    var employee = new Employee
                    {
                        Name = parts[0],
                        Surname = parts[1],
                        Age = int.Parse(parts[2]),
                        Position = parts[3],
                        Salary = decimal.Parse(parts[4])
                    };
                    Employees.Add(employee);
                }
                else
                {
                    throw new FormatException("The data in the file is not in the correct format.");
                }
            }
        }

        public void WriteEmployeesToFile(string path)
        {
            var lines = Employees.Select(e => $"{e.Name},{e.Surname},{e.Age},{e.Position},{e.Salary}");
            File.WriteAllLines(path, lines);
        }
    }
}
